export default {
  title: 'Freigabe',
  shared_resources: 'Freigegebene Ressourcen',
  shared_tool: 'Freigegebenes Tool',
  shared_model: 'Freigegebenes Modell',
  shared_knowledge: 'Freigegebenes Wissen',
  authorized_workspace: 'Workspace autorisieren',
  authorized_tip: ' ',
  select_workspace: 'Workspace auswählen',
  allCheck: 'Alle auswählen',
  BLACK_LIST: 'Blacklist',
  WHITE_LIST: 'Whitelist',
  type: 'Typ',
}
